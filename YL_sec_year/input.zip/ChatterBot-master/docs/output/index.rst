===============
Output Adapters
===============

.. toctree::
   :maxdepth: 1

   create-an-output-adapter

Output format adapter
=====================

.. autofunction:: chatterbot.output.OutputAdapter

The output adapter allows the chat bot to return a response in
as a `Statement` object.

.. code-block:: python

   chatbot = ChatBot(
       "My ChatterBot",
       output_adapter="chatterbot.output.OutputAdapter",
       output_format="text"
   )

Terminal output adapter
=======================

.. autofunction:: chatterbot.output.TerminalAdapter

The output terminal adapter allows a user to type into their terminal to
communicate with the chat bot.

.. code-block:: python

   chatbot = ChatBot(
       "My ChatterBot",
       output_adapter="chatterbot.output.TerminalAdapter"
   )

Gitter output adapter
=====================

.. autofunction:: chatterbot.output.Gitter

.. code-block:: python

   chatbot = ChatBot(
       "My ChatterBot",
       output_adapter="chatterbot.output.Gitter",
       gitter_api_token="my-gitter-api-token",
       gitter_room="my-room-name",
       gitter_only_respond_to_mentions=True,
   )

.. _microsoft-output-adapter:

Microsoft Bot Framework output adapter
======================================

.. autofunction:: chatterbot.output.Microsoft

This is an output adapter that allows a ChatterBot instance to send responses
to a `Microsoft`_ using *Direct Line protocol*.

Be sure to also see the documentation for the :ref:`Microsoft input adapter <microsoft-input-adapter>`.

.. code-block:: python

   chatbot = ChatBot(
       "My ChatterBot",
       output_adapter="chatterbot.output.Microsoft",
       directline_host="https://directline.botframework.com",
       conversation_id="IEyJvnDULgn",
       direct_line_token_or_secret="RCurR_XV9ZA.cwA.BKA.iaJrC8xpy8qbOF5xnR2vtCX7CZj0LdjAPGfiCpg4Fv0",
   )

Mailgun output adapter
======================

.. autofunction:: chatterbot.output.Mailgun

The Mailgun adapter allows the chat bot to send emails using the
`Mailgun API`_.

.. literalinclude:: ../../examples/mailgun.py
   :language: python

.. _`Mailgun API`: https://documentation.mailgun.com/api_reference.html
.. _Microsoft: https://docs.botframework.com/en-us/restapi/directline/#/Conversations
