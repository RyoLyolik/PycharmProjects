from tests.base_case import ChatBotTestCase
from chatterbot.input import InputAdapter


class InputAdapterTestCase(ChatBotTestCase):
    """
    This test case is for the InputAdapter base class.
    Although this class is not intended for direct use,
    this test case ensures that exceptions requiring
    basic functionality are triggered when needed.
    """

    def setUp(self):
        super().setUp()
        self.adapter = InputAdapter(self.chatbot)

    def test_process_response(self):
        with self.assertRaises(InputAdapter.AdapterMethodNotImplementedError):
            self.adapter.process_input('test statement')
